const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();

const NSE_API = 'https://www.nseindia.com/api';
const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive'
};

// Middleware to handle CORS
app.use(cors());

// Endpoint to fetch Nifty 50 stocks
app.get('/api/stocks/nifty50', async (req, res) => {
    try {
        const response = await axios.get(`${NSE_API}/equity-stockIndices?index=NIFTY 50`, { headers });
        res.json(response.data.data);
    } catch (error) {
        console.error('Error fetching Nifty 50 data:', error);
        res.status(500).json({ error: 'Unable to fetch stock data' });
    }
});

// Endpoint to fetch indices data
app.get('/api/stocks/indices', async (req, res) => {
    try {
        const response = await axios.get(`${NSE_API}/allIndices`, { headers });
        res.json(response.data.data);
    } catch (error) {
        console.error('Error fetching indices data:', error);
        res.status(500).json({ error: 'Unable to fetch indices data' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
}); 