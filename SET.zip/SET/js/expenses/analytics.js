class ExpenseAnalytics {
    constructor(tracker) {
        this.tracker = tracker;
        this.initializeCharts();
        this.initializePredictions();
    }

    initializeCharts() {
        this.createTrendChart();
        this.createCategoryBreakdown();
        this.createDailySpendingChart();
        this.createBudgetComparisonChart();
    }

    createTrendChart() {
        const ctx = document.getElementById('trendChart').getContext('2d');
        const monthlyData = this.getMonthlyTrends();

        this.trendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: monthlyData.labels,
                datasets: [{
                    label: 'Monthly Expenses',
                    data: monthlyData.expenses,
                    borderColor: 'rgb(37, 99, 235)',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    fill: true,
                    tension: 0.4
                }, {
                    label: 'Predicted Expenses',
                    data: monthlyData.predictions,
                    borderColor: 'rgba(37, 99, 235, 0.5)',
                    borderDash: [5, 5],
                    fill: false
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Expense Trends & Predictions'
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => `₹${context.parsed.y.toLocaleString('en-IN')}`
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => `₹${value.toLocaleString('en-IN')}`
                        }
                    }
                }
            }
        });
    }

    createCategoryBreakdown() {
        const ctx = document.getElementById('categoryChart').getContext('2d');
        const data = this.getCategoryBreakdown();

        this.categoryChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: data.colors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const value = context.raw;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `₹${value.toLocaleString('en-IN')} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    createDailySpendingChart() {
        const ctx = document.getElementById('dailyChart').getContext('2d');
        const data = this.getDailySpending();

        this.dailyChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Daily Spending',
                    data: data.values,
                    backgroundColor: 'rgba(37, 99, 235, 0.8)',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: (context) => `₹${context.parsed.y.toLocaleString('en-IN')}`
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => `₹${value.toLocaleString('en-IN')}`
                        }
                    }
                }
            }
        });
    }

    createBudgetComparisonChart() {
        const ctx = document.getElementById('budgetChart').getContext('2d');
        const data = this.getBudgetComparison();

        this.budgetChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.categories,
                datasets: [{
                    label: 'Budget',
                    data: data.budgets,
                    backgroundColor: 'rgba(37, 99, 235, 0.3)',
                    borderColor: 'rgba(37, 99, 235, 0.8)',
                    borderWidth: 1
                }, {
                    label: 'Actual',
                    data: data.actual,
                    backgroundColor: 'rgba(37, 99, 235, 0.8)'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Budget vs Actual Spending'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => `₹${value.toLocaleString('en-IN')}`
                        }
                    }
                }
            }
        });
    }

    getInsights() {
        const insights = [];
        const monthlyData = this.getMonthlyTrends();
        const categoryData = this.getCategoryBreakdown();
        
        // Trend Analysis
        const lastThreeMonths = monthlyData.expenses.slice(-3);
        const trend = this.calculateTrend(lastThreeMonths);
        insights.push({
            type: trend > 0 ? 'warning' : 'success',
            icon: trend > 0 ? 'arrow-up' : 'arrow-down',
            title: 'Spending Trend',
            message: `Your expenses are ${trend > 0 ? 'increasing' : 'decreasing'} by ${Math.abs(trend).toFixed(1)}% month over month`
        });

        // Category Analysis
        const topCategory = this.getTopCategory();
        insights.push({
            type: 'info',
            icon: 'pie-chart',
            title: 'Top Expense Category',
            message: `${topCategory.name} accounts for ${topCategory.percentage}% of your expenses`
        });

        // Budget Analysis
        const budgetStatus = this.getBudgetStatus();
        insights.push({
            type: budgetStatus.overBudget ? 'warning' : 'success',
            icon: budgetStatus.overBudget ? 'alert' : 'check',
            title: 'Budget Status',
            message: budgetStatus.message
        });

        return insights;
    }

    // Helper methods...
    calculateTrend(data) {
        if (data.length < 2) return 0;
        const changes = [];
        for (let i = 1; i < data.length; i++) {
            changes.push(((data[i] - data[i-1]) / data[i-1]) * 100);
        }
        return changes.reduce((a, b) => a + b, 0) / changes.length;
    }

    getTopCategory() {
        const categoryData = this.getCategoryBreakdown();
        const maxIndex = categoryData.values.indexOf(Math.max(...categoryData.values));
        const total = categoryData.values.reduce((a, b) => a + b, 0);
        const percentage = ((categoryData.values[maxIndex] / total) * 100).toFixed(1);
        
        return {
            name: categoryData.labels[maxIndex],
            percentage
        };
    }

    getBudgetStatus() {
        const totalBudget = this.tracker.budgets.total;
        const totalExpenses = this.tracker.getThisMonthExpenses();
        const overBudget = totalExpenses > totalBudget;
        
        return {
            overBudget,
            message: overBudget 
                ? `You're over budget by ₹${(totalExpenses - totalBudget).toLocaleString('en-IN')}`
                : `You're under budget by ₹${(totalBudget - totalExpenses).toLocaleString('en-IN')}`
        };
    }

    updateCharts() {
        this.trendChart.update();
        this.categoryChart.update();
        this.dailyChart.update();
        this.budgetChart.update();
        this.updateInsights();
    }
} 