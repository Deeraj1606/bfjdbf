class ExpenseTracker {
    constructor() {
        this.expenses = JSON.parse(localStorage.getItem('expenses')) || [];
        this.budgets = JSON.parse(localStorage.getItem('budgets')) || {
            total: 0,
            categories: {}
        };
        
        this.categories = {
            food: { icon: 'restaurant', color: '#22c55e' },
            transport: { icon: 'car', color: '#3b82f6' },
            shopping: { icon: 'shopping-bag', color: '#ec4899' },
            bills: { icon: 'bill', color: '#f59e0b' },
            entertainment: { icon: 'gamepad', color: '#8b5cf6' },
            health: { icon: 'heart-pulse', color: '#ef4444' },
            other: { icon: 'more', color: '#64748b' }
        };
        
        this.initializeElements();
        this.initializeEventListeners();
        this.updateUI();
        this.initializeCharts();
    }

    initializeElements() {
        // Modals
        this.addExpenseModal = document.getElementById('addExpenseModal');
        this.setBudgetModal = document.getElementById('setBudgetModal');
        
        // Forms
        this.expenseForm = document.getElementById('expenseForm');
        this.budgetForm = document.getElementById('budgetForm');
        
        // Lists and filters
        this.expensesList = document.getElementById('expensesList');
        this.categoryFilter = document.getElementById('categoryFilter');
        this.dateFilter = document.getElementById('dateFilter');
        
        // Overview elements
        this.monthlyExpensesEl = document.getElementById('monthlyExpenses');
        this.monthlyBudgetEl = document.getElementById('monthlyBudget');
        this.budgetUtilizationEl = document.getElementById('budgetUtilization');

        // Quick add form
        this.quickForm = document.getElementById('quickExpenseForm');
        this.expenseList = document.querySelector('.expense-list');
        this.searchInput = document.querySelector('.search-box input');
        this.filterSelect = document.querySelector('.filter-select');
        this.exportBtn = document.getElementById('exportBtn');

        // Stats elements
        this.monthlyTotal = document.querySelector('.stat-value');
        this.monthlyChange = document.querySelector('.stat-change');
    }

    initializeEventListeners() {
        // Modal triggers
        document.getElementById('addExpenseBtn').addEventListener('click', () => this.openExpenseModal());
        document.getElementById('addBudgetBtn').addEventListener('click', () => this.openBudgetModal());
        
        // Modal close buttons
        document.getElementById('closeExpenseModal').addEventListener('click', () => this.closeExpenseModal());
        document.getElementById('closeBudgetModal').addEventListener('click', () => this.closeBudgetModal());
        
        // Form submissions
        this.expenseForm.addEventListener('submit', (e) => this.handleExpenseSubmit(e));
        this.budgetForm.addEventListener('submit', (e) => this.handleBudgetSubmit(e));
        
        // Filters
        this.categoryFilter.addEventListener('change', () => this.filterExpenses());
        this.dateFilter.addEventListener('change', () => this.filterExpenses());
        
        // Set default date in expense form
        document.getElementById('expenseDate').valueAsDate = new Date();

        // Quick add form
        this.quickForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.addExpense({
                amount: parseFloat(e.target.elements[0].value),
                description: e.target.elements[1].value,
                category: e.target.elements[2].value,
                date: new Date().toISOString(),
                id: Date.now()
            });
            e.target.reset();
        });

        // Search and filter
        this.searchInput.addEventListener('input', () => this.filterExpenses());
        this.filterSelect.addEventListener('change', () => this.filterExpenses());

        // Export
        this.exportBtn.addEventListener('click', () => this.exportExpenses());
    }

    openExpenseModal() {
        this.addExpenseModal.classList.add('active');
    }

    closeExpenseModal() {
        this.addExpenseModal.classList.remove('active');
        this.expenseForm.reset();
    }

    openBudgetModal() {
        this.setBudgetModal.classList.add('active');
        // Pre-fill existing budget values
        document.getElementById('totalBudget').value = this.budgets.total;
        Object.entries(this.budgets.categories).forEach(([category, amount]) => {
            const input = document.getElementById(`${category}Budget`);
            if (input) input.value = amount;
        });
    }

    closeBudgetModal() {
        this.setBudgetModal.classList.remove('active');
        this.budgetForm.reset();
    }

    handleExpenseSubmit(e) {
        e.preventDefault();
        
        const expenseData = {
            title: document.getElementById('expenseTitle').value,
            amount: parseFloat(document.getElementById('expenseAmount').value),
            category: document.getElementById('expenseCategory').value,
            date: document.getElementById('expenseDate').value,
            notes: document.getElementById('expenseNotes').value,
            timestamp: new Date().toISOString()
        };

        const editId = this.expenseForm.dataset.editId;
        if (editId) {
            // Update existing expense
            const index = this.expenses.findIndex(e => e.id === parseInt(editId));
            if (index !== -1) {
                this.expenses[index] = { ...this.expenses[index], ...expenseData };
            }
            delete this.expenseForm.dataset.editId;
        } else {
            // Add new expense
            expenseData.id = Date.now();
            this.expenses.unshift(expenseData);
        }

        this.saveExpenses();
        this.updateUI();
        this.closeExpenseModal();
    }

    handleBudgetSubmit(e) {
        e.preventDefault();
        
        this.budgets.total = parseFloat(document.getElementById('totalBudget').value);
        this.budgets.categories = {
            food: parseFloat(document.getElementById('foodBudget').value) || 0,
            transportation: parseFloat(document.getElementById('transportationBudget').value) || 0,
            // Add more categories
        };
        
        this.saveBudgets();
        this.updateUI();
        this.closeBudgetModal();
    }

    saveExpenses() {
        localStorage.setItem('expenses', JSON.stringify(this.expenses));
    }

    saveBudgets() {
        localStorage.setItem('budgets', JSON.stringify(this.budgets));
    }

    filterExpenses() {
        const category = this.categoryFilter.value;
        const dateRange = this.dateFilter.value;
        
        let filtered = [...this.expenses];
        
        // Apply category filter
        if (category !== 'all') {
            filtered = filtered.filter(expense => expense.category === category);
        }
        
        // Apply date filter
        const today = new Date();
        const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        
        switch (dateRange) {
            case 'thisMonth':
                filtered = filtered.filter(expense => new Date(expense.date) >= firstDayOfMonth);
                break;
            case 'lastMonth':
                const firstDayOfLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
                const lastDayOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
                filtered = filtered.filter(expense => {
                    const date = new Date(expense.date);
                    return date >= firstDayOfLastMonth && date <= lastDayOfLastMonth;
                });
                break;
            // Add more date range filters
        }
        
        this.renderExpensesList(filtered);
    }

    renderExpensesList(expenses) {
        this.expensesList.innerHTML = expenses.map(expense => `
            <div class="expense-item" data-id="${expense.id}">
                <div class="expense-icon" style="background: ${this.categories[expense.category].color}20; color: ${this.categories[expense.category].color}">
                    <i class="ri-${this.categories[expense.category].icon}-line"></i>
                </div>
                <div class="expense-details">
                    <div class="expense-title">${expense.title}</div>
                    <div class="expense-meta">
                        <span class="category">
                            <i class="ri-price-tag-3-line"></i>
                            ${expense.category}
                        </span>
                        <span class="date">
                            <i class="ri-calendar-line"></i>
                            ${new Date(expense.date).toLocaleDateString()}
                        </span>
                        ${expense.notes ? `
                            <span class="expense-notes" title="${expense.notes}">
                                <i class="ri-file-text-line"></i>
                                Note
                            </span>
                        ` : ''}
                    </div>
                </div>
                <div class="expense-amount">₹${expense.amount.toLocaleString('en-IN')}</div>
                <div class="expense-actions">
                    <button class="expense-action-btn edit" onclick="expenseTracker.editExpense(${expense.id})">
                        <i class="ri-edit-line"></i>
                    </button>
                    <button class="expense-action-btn delete" onclick="expenseTracker.deleteExpense(${expense.id})">
                        <i class="ri-delete-bin-line"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    getCategoryIcon(category) {
        const icons = {
            food: 'restaurant',
            transportation: 'car',
            utilities: 'home',
            shopping: 'shopping-bag',
            entertainment: 'game',
            health: 'heart',
            education: 'book',
            others: 'more'
        };
        return icons[category] || 'more';
    }

    updateUI() {
        this.filterExpenses();
        this.updateOverviewCards();
        this.updateStats();
        this.updateCharts();
        // Trigger analytics update if analytics module is loaded
        if (window.expenseAnalytics) {
            window.expenseAnalytics.updateCharts();
        }
    }

    updateOverviewCards() {
        const thisMonth = this.getThisMonthExpenses();
        this.monthlyExpensesEl.textContent = thisMonth.toLocaleString('en-IN');
        this.monthlyBudgetEl.textContent = this.budgets.total.toLocaleString('en-IN');
        
        const utilization = this.budgets.total ? (thisMonth / this.budgets.total * 100) : 0;
        this.budgetUtilizationEl.textContent = utilization.toFixed(1);
        
        // Add warning class if over budget
        this.budgetUtilizationEl.parentElement.classList.toggle('warning', utilization > 100);
    }

    getThisMonthExpenses() {
        const firstDayOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
        return this.expenses
            .filter(expense => new Date(expense.date) >= firstDayOfMonth)
            .reduce((sum, expense) => sum + expense.amount, 0);
    }

    editExpense(id) {
        const expense = this.expenses.find(e => e.id === id);
        if (!expense) return;

        // Populate form with expense data
        document.getElementById('expenseTitle').value = expense.title;
        document.getElementById('expenseAmount').value = expense.amount;
        document.getElementById('expenseCategory').value = expense.category;
        document.getElementById('expenseDate').value = expense.date;
        document.getElementById('expenseNotes').value = expense.notes || '';

        // Update form for edit mode
        this.expenseForm.dataset.editId = id;
        document.querySelector('#addExpenseModal .modal-header h3').textContent = 'Edit Expense';
        document.querySelector('#addExpenseModal .btn-primary').textContent = 'Save Changes';

        this.openExpenseModal();
    }

    deleteExpense(id) {
        if (confirm('Are you sure you want to delete this expense?')) {
            this.expenses = this.expenses.filter(e => e.id !== id);
            this.saveExpenses();
            this.updateUI();
        }
    }

    updateStats() {
        const thisMonth = this.getMonthlyTotal(new Date());
        const lastMonth = this.getMonthlyTotal(new Date(new Date().setMonth(new Date().getMonth() - 1)));
        const change = ((thisMonth - lastMonth) / lastMonth) * 100;

        this.monthlyTotal.textContent = `₹${thisMonth.toLocaleString('en-IN')}`;
        this.monthlyChange.textContent = `${change >= 0 ? '↑' : '↓'} ${Math.abs(change).toFixed(1)}% vs last month`;
        this.monthlyChange.className = `stat-change ${change >= 0 ? 'negative' : 'positive'}`;
    }

    getMonthlyTotal(date) {
        return this.expenses
            .filter(e => new Date(e.date).getMonth() === date.getMonth())
            .reduce((sum, e) => sum + e.amount, 0);
    }

    initializeCharts() {
        // Category breakdown chart
        const categoryData = Object.entries(
            this.expenses.reduce((acc, expense) => {
                acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
                return acc;
            }, {})
        );

        new Chart(document.getElementById('categoryChart'), {
            type: 'doughnut',
            data: {
                labels: categoryData.map(([category]) => category),
                datasets: [{
                    data: categoryData.map(([, amount]) => amount),
                    backgroundColor: categoryData.map(([category]) => this.categories[category].color)
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    exportExpenses() {
        const csv = [
            ['Date', 'Description', 'Category', 'Amount'],
            ...this.expenses.map(e => [
                new Date(e.date).toLocaleDateString(),
                e.title,
                e.category,
                e.amount
            ])
        ].map(row => row.join(',')).join('\n');

        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `expenses_${new Date().toLocaleDateString()}.csv`;
        a.click();
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="ri-${type === 'success' ? 'check' : 'error-warning'}-line"></i>
            ${message}
        `;
        document.body.appendChild(notification);

        // Animate in
        setTimeout(() => notification.classList.add('show'), 10);

        // Remove after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Initialize tracker when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.expenseTracker = new ExpenseTracker();
}); 