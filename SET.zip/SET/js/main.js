// Theme handling
const initTheme = () => {
    const theme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', theme);
};

// Navigation handling
const initNavigation = () => {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            
            // Handle page navigation here
            const page = link.textContent.toLowerCase();
            loadPage(page);
        });
    });
};

// Chart initialization
const initCharts = () => {
    const expenseCtx = document.getElementById('expenseChart').getContext('2d');
    
    new Chart(expenseCtx, {
        type: 'bar',
        data: {
            labels: ['Housing', 'Food', 'Transport', 'Utilities', 'Entertainment', 'Healthcare'],
            datasets: [{
                label: 'Monthly Expenses',
                data: [120000, 45000, 30000, 18000, 22000, 15000],
                backgroundColor: 'rgba(0, 102, 255, 0.8)',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => '₹' + value.toLocaleString()
                    }
                }
            }
        }
    });
};

class App {
    constructor() {
        this.initializeTheme();
        this.initializeNavigation();
        this.addScrollEffects();
    }

    initializeTheme() {
        const theme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', theme);

        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                const currentTheme = document.documentElement.getAttribute('data-theme');
                const newTheme = currentTheme === 'light' ? 'dark' : 'light';
                
                document.documentElement.setAttribute('data-theme', newTheme);
                localStorage.setItem('theme', newTheme);
                
                // Update icon
                themeToggle.innerHTML = `<i class="ri-${newTheme === 'light' ? 'sun' : 'moon'}-line"></i>`;
            });
        }
    }

    initializeNavigation() {
        const currentPage = window.location.pathname.split('/').pop().split('.')[0] || 'dashboard';
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            const page = link.getAttribute('data-page');
            if (page === currentPage) {
                link.classList.add('active');
            }
            
            // Add hover effect
            link.addEventListener('mouseenter', this.addNavHoverEffect);
            link.addEventListener('mouseleave', this.removeNavHoverEffect);
        });
    }

    addScrollEffects() {
        let lastScroll = 0;
        const header = document.querySelector('.header');

        window.addEventListener('scroll', () => {
            const currentScroll = window.pageYOffset;
            
            // Add shadow and adjust transparency based on scroll
            if (currentScroll > 0) {
                header.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
                header.style.background = `rgba(var(--background-rgb), 0.9)`;
            } else {
                header.style.boxShadow = 'none';
                header.style.background = `rgba(var(--background-rgb), 0.8)`;
            }

            // Hide/show header based on scroll direction
            if (currentScroll > lastScroll && currentScroll > 100) {
                header.style.transform = 'translateY(-100%)';
            } else {
                header.style.transform = 'translateY(0)';
            }
            
            lastScroll = currentScroll;
        });
    }

    addNavHoverEffect(e) {
        const link = e.currentTarget;
        const rect = link.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        link.style.setProperty('--x', `${x}px`);
        link.style.setProperty('--y', `${y}px`);
        link.classList.add('nav-hover');
    }

    removeNavHoverEffect(e) {
        e.currentTarget.classList.remove('nav-hover');
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new App();
}); 