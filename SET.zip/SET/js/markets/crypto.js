class CryptoMarket {
    constructor() {
        this.tableBody = document.getElementById('cryptoTableBody');
        this.searchInput = document.querySelector('.search-input');
        this.sortSelect = document.querySelector('.sort-select');
        this.cryptoData = [];
        this.COINGECKO_API = 'https://api.coingecko.com/api/v3';
        
        this.initializeEventListeners();
        this.fetchData();
        // Update every 1 minute
        setInterval(() => this.fetchData(), 60000);
    }

    initializeEventListeners() {
        this.searchInput.addEventListener('input', () => this.filterData());
        this.sortSelect.addEventListener('change', () => this.sortData());
    }

    async fetchData() {
        try {
            const response = await fetch(
                `${this.COINGECKO_API}/coins/markets?vs_currency=inr&order=market_cap_desc&per_page=100&sparkline=true`
            );
            const data = await response.json();
            
            this.cryptoData = data.map(coin => ({
                id: coin.id,
                name: coin.name,
                symbol: coin.symbol.toUpperCase(),
                price: coin.current_price,
                change24h: coin.price_change_percentage_24h,
                marketCap: coin.market_cap,
                volume: coin.total_volume,
                image: coin.image,
                sparkline: coin.sparkline_in_7d?.price || []
            }));

            this.renderTable();
            this.updateOverviewCards();
        } catch (error) {
            console.error('Error fetching crypto data:', error);
            // Show error message to user
            this.showError('Unable to fetch cryptocurrency data. Please try again later.');
        }
    }

    renderTable() {
        this.tableBody.innerHTML = this.cryptoData.map(crypto => `
            <tr>
                <td>
                    <div class="crypto-name">
                        <img src="${crypto.image}" alt="${crypto.name}" width="24" height="24">
                        <div>
                            <div class="name">${crypto.name}</div>
                            <div class="symbol">${crypto.symbol}</div>
                        </div>
                    </div>
                </td>
                <td>₹${crypto.price.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })}</td>
                <td class="${crypto.change24h >= 0 ? 'positive' : 'negative'}">
                    ${crypto.change24h >= 0 ? '+' : ''}${crypto.change24h.toFixed(2)}%
                </td>
                <td>₹${(crypto.marketCap / 10000000).toFixed(2)}Cr</td>
                <td>₹${(crypto.volume / 10000000).toFixed(2)}Cr</td>
                <td>
                    <canvas class="sparkline" data-values="${crypto.sparkline.join(',')}"></canvas>
                </td>
            </tr>
        `).join('');

        // Initialize sparkline charts
        document.querySelectorAll('.sparkline').forEach(canvas => {
            const values = canvas.dataset.values.split(',').map(Number);
            this.createSparkline(canvas, values);
        });
    }

    createSparkline(canvas, data) {
        new Chart(canvas, {
            type: 'line',
            data: {
                labels: new Array(data.length).fill(''),
                datasets: [{
                    data: data,
                    borderColor: data[0] <= data[data.length - 1] ? '#22c55e' : '#ef4444',
                    borderWidth: 2,
                    pointRadius: 0,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        display: false
                    },
                    y: {
                        display: false
                    }
                }
            }
        });
    }

    filterData() {
        const searchTerm = this.searchInput.value.toLowerCase();
        const filtered = this.cryptoData.filter(crypto => 
            crypto.name.toLowerCase().includes(searchTerm) || 
            crypto.symbol.toLowerCase().includes(searchTerm)
        );
        this.renderFilteredData(filtered);
    }

    sortData() {
        const sortBy = this.sortSelect.value;
        const sorted = [...this.cryptoData].sort((a, b) => {
            switch (sortBy) {
                case 'marketcap':
                    return b.marketCap - a.marketCap;
                case 'volume':
                    return b.volume - a.volume;
                case 'change':
                    return b.change24h - a.change24h;
                default:
                    return 0;
            }
        });
        this.renderFilteredData(sorted);
    }

    renderFilteredData(data) {
        this.cryptoData = data;
        this.renderTable();
    }

    updateOverviewCards() {
        // Update top 3 cryptocurrencies in overview cards
        const topCryptos = this.cryptoData.slice(0, 3);
        topCryptos.forEach((crypto, index) => {
            const card = document.querySelector(`.overview-card:nth-child(${index + 1})`);
            if (card) {
                card.querySelector('h3').textContent = crypto.name;
                card.querySelector('.price').textContent = `₹${crypto.price.toLocaleString('en-IN')}`;
                card.querySelector('.change').textContent = 
                    `${crypto.change24h >= 0 ? '+' : ''}${crypto.change24h.toFixed(2)}%`;
                card.querySelector('.change').className = 
                    `change ${crypto.change24h >= 0 ? 'positive' : 'negative'}`;
                
                // Update mini chart
                const canvas = card.querySelector('canvas');
                this.createSparkline(canvas, crypto.sparkline);
            }
        });
    }

    showError(message) {
        // Create or update error message element
        let errorEl = document.querySelector('.error-message');
        if (!errorEl) {
            errorEl = document.createElement('div');
            errorEl.className = 'error-message';
            this.tableBody.parentElement.insertBefore(errorEl, this.tableBody);
        }
        errorEl.textContent = message;
        errorEl.style.display = 'block';

        // Hide after 5 seconds
        setTimeout(() => {
            errorEl.style.display = 'none';
        }, 5000);
    }
}

// Initialize market when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CryptoMarket();
}); 