class StockMarket {
    constructor() {
        this.tableBody = document.getElementById('stocksTableBody');
        this.searchInput = document.querySelector('#stocks .search-input');
        this.sortSelect = document.querySelector('#stocks .sort-select');
        this.stockData = [];
        
        // You'll need to set up a proxy server to handle CORS and API key
        this.API_ENDPOINT = '/api/stocks'; // Your backend proxy endpoint

        this.initializeEventListeners();
        this.fetchData();
        // Update every 1 minute
        setInterval(() => this.fetchData(), 60000);
    }

    initializeEventListeners() {
        this.searchInput.addEventListener('input', () => this.filterData());
        this.sortSelect.addEventListener('change', () => this.sortData());
    }

    async fetchData() {
        try {
            // Fetch Nifty 50 stocks data
            const response = await fetch(`${this.API_ENDPOINT}/nifty50`);
            const data = await response.json();

            this.stockData = data.map(stock => ({
                symbol: stock.symbol,
                name: stock.companyName,
                price: stock.lastPrice,
                change: stock.pChange,
                volume: stock.totalTradedVolume,
                marketCap: stock.marketCap,
                dayHigh: stock.dayHigh,
                dayLow: stock.dayLow,
                pe: stock.pe || '-',
                sector: stock.industry
            }));

            this.renderTable();
            this.updateIndicesCards();
        } catch (error) {
            console.error('Error fetching stock data:', error);
            this.showError('Unable to fetch stock market data. Please try again later.');
        }
    }

    async updateIndicesCards() {
        try {
            // Fetch indices data
            const response = await fetch(`${this.API_ENDPOINT}/indices`);
            const data = await response.json();

            // Update indices cards
            ['NIFTY 50', 'SENSEX', 'BANKNIFTY'].forEach(index => {
                const indexData = data.find(i => i.name === index);
                if (indexData) {
                    const card = document.querySelector(`.overview-card:contains('${index}')`);
                    if (card) {
                        card.querySelector('.price').textContent = indexData.lastPrice.toFixed(2);
                        card.querySelector('.change').textContent = 
                            `${indexData.change >= 0 ? '+' : ''}${indexData.change.toFixed(2)}%`;
                        card.querySelector('.change').className = 
                            `change ${indexData.change >= 0 ? 'positive' : 'negative'}`;
                    }
                }
            });
        } catch (error) {
            console.error('Error fetching indices data:', error);
        }
    }

    renderTable() {
        this.tableBody.innerHTML = this.stockData.map(stock => `
            <tr>
                <td>${stock.symbol}</td>
                <td>
                    <div class="stock-info">
                        <div>
                            <div class="name">${stock.name}</div>
                            <div class="sector">${stock.sector}</div>
                        </div>
                    </div>
                </td>
                <td>₹${stock.price.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })}</td>
                <td class="${stock.change >= 0 ? 'positive' : 'negative'}">
                    ${stock.change >= 0 ? '+' : ''}${stock.change}%
                </td>
                <td>${(stock.volume / 100000).toFixed(2)}L</td>
                <td>₹${(stock.marketCap / 10000000).toFixed(2)}Cr</td>
                <td>${stock.pe}</td>
                <td>
                    <canvas class="sparkline" data-values="${stock.sparkline.join(',')}"></canvas>
                </td>
            </tr>
        `).join('');

        // Initialize sparkline charts
        document.querySelectorAll('#stocks .sparkline').forEach(canvas => {
            const values = canvas.dataset.values.split(',').map(Number);
            this.createSparkline(canvas, values);
        });
    }

    initializeCharts() {
        // Initialize Indian index charts
        const indices = {
            'niftyChart': [21800, 21820, 21835, 21845, 21853],
            'sensexChart': [72050, 72080, 72095, 72110, 72123],
            'bankNiftyChart': [46000, 45995, 45990, 45985, 45987]
        };

        Object.entries(indices).forEach(([id, data]) => {
            const ctx = document.getElementById(id).getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: new Array(data.length).fill(''),
                    datasets: [{
                        data: data,
                        borderColor: data[0] <= data[data.length - 1] ? '#22c55e' : '#ef4444',
                        borderWidth: 2,
                        pointRadius: 0,
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { display: false },
                        y: { display: false }
                    }
                }
            });
        });
    }

    createSparkline(canvas, data) {
        new Chart(canvas, {
            type: 'line',
            data: {
                labels: new Array(data.length).fill(''),
                datasets: [{
                    data: data,
                    borderColor: data[0] <= data[data.length - 1] ? '#22c55e' : '#ef4444',
                    borderWidth: 1.5,
                    pointRadius: 0,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { display: false },
                    y: { display: false }
                }
            }
        });
    }

    filterData() {
        const searchTerm = this.searchInput.value.toLowerCase();
        const filtered = this.stockData.filter(stock => 
            stock.symbol.toLowerCase().includes(searchTerm) || 
            stock.name.toLowerCase().includes(searchTerm)
        );
        this.renderFilteredData(filtered);
    }

    sortData() {
        const sortBy = this.sortSelect.value;
        const sorted = [...this.stockData].sort((a, b) => {
            switch (sortBy) {
                case 'marketcap':
                    return b.marketCap - a.marketCap;
                case 'price':
                    return b.price - a.price;
                case 'change':
                    return b.change - a.change;
                case 'volume':
                    return b.volume - a.volume;
                default:
                    return 0;
            }
        });
        this.renderFilteredData(sorted);
    }

    renderFilteredData(data) {
        this.stockData = data;
        this.renderTable();
    }

    // Add new methods for filtering
    filterByMarketCap(cap) {
        if (cap === 'all') return this.stockData;
        return this.stockData.filter(stock => stock.marketCap === cap);
    }

    filterBySector(sector) {
        if (sector === 'all') return this.stockData;
        return this.stockData.filter(stock => stock.sector.toLowerCase() === sector);
    }

    showError(message) {
        // Create or update error message element
        let errorEl = document.querySelector('.error-message');
        if (!errorEl) {
            errorEl = document.createElement('div');
            errorEl.className = 'error-message';
            this.tableBody.parentElement.insertBefore(errorEl, this.tableBody);
        }
        errorEl.textContent = message;
        errorEl.style.display = 'block';

        // Hide after 5 seconds
        setTimeout(() => {
            errorEl.style.display = 'none';
        }, 5000);
    }
}

// Initialize market when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new StockMarket();
}); 