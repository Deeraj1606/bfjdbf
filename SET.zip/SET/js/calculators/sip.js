class SIPCalculator {
    constructor() {
        this.form = document.getElementById('sipForm');
        this.result = document.getElementById('sipResult');
        this.chart = null;

        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Form submission
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.calculateSIP();
        });

        // Sync range inputs with number inputs
        ['monthlyInvestment', 'expectedReturn', 'timePeriod'].forEach(id => {
            const input = document.getElementById(id);
            const range = document.getElementById(id + 'Range');

            input.addEventListener('input', () => range.value = input.value);
            range.addEventListener('input', () => input.value = range.value);
        });
    }

    calculateSIP() {
        const monthlyInvestment = parseFloat(document.getElementById('monthlyInvestment').value);
        const expectedReturn = parseFloat(document.getElementById('expectedReturn').value);
        const years = parseFloat(document.getElementById('timePeriod').value);

        const monthlyRate = expectedReturn / 12 / 100;
        const months = years * 12;
        
        const futureValue = monthlyInvestment * 
            ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * 
            (1 + monthlyRate);

        const totalInvestment = monthlyInvestment * months;
        const wealthGained = futureValue - totalInvestment;

        this.displayResults(futureValue, totalInvestment, wealthGained);
        this.updateChart(years, monthlyInvestment, expectedReturn);
    }

    displayResults(futureValue, totalInvestment, wealthGained) {
        this.result.style.display = 'block';
        
        this.result.querySelector('.result-amount').textContent = 
            `₹${Math.round(futureValue).toLocaleString()}`;
        
        this.result.querySelector('.total-investment').textContent = 
            `₹${Math.round(totalInvestment).toLocaleString()}`;
        
        this.result.querySelector('.wealth-gained').textContent = 
            `₹${Math.round(wealthGained).toLocaleString()}`;
    }

    updateChart(years, monthlyInvestment, expectedReturn) {
        const monthlyRate = expectedReturn / 12 / 100;
        const data = [];
        let investment = 0;
        let wealth = 0;

        for (let year = 0; year <= years; year++) {
            investment = monthlyInvestment * year * 12;
            wealth = monthlyInvestment * 
                ((Math.pow(1 + monthlyRate, year * 12) - 1) / monthlyRate) * 
                (1 + monthlyRate);

            data.push({
                year: year,
                investment: Math.round(investment),
                wealth: Math.round(wealth)
            });
        }

        if (this.chart) {
            this.chart.destroy();
        }

        const ctx = document.getElementById('sipChart').getContext('2d');
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.map(d => `Year ${d.year}`),
                datasets: [
                    {
                        label: 'Total Investment',
                        data: data.map(d => d.investment),
                        borderColor: 'rgba(0, 102, 255, 0.5)',
                        backgroundColor: 'rgba(0, 102, 255, 0.1)',
                        fill: true
                    },
                    {
                        label: 'Wealth',
                        data: data.map(d => d.wealth),
                        borderColor: 'rgba(0, 102, 255, 1)',
                        backgroundColor: 'rgba(0, 102, 255, 0.2)',
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => '₹' + value.toLocaleString()
                        }
                    }
                }
            }
        });
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SIPCalculator();
}); 