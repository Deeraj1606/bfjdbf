class RetirementCalculator {
    constructor() {
        this.form = document.getElementById('retirementForm');
        this.result = document.getElementById('retirementResult');
        this.charts = {
            corpus: null,
            investment: null
        };

        this.initializeEventListeners();
    }

    initializeEventListeners() {
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.calculateRetirement();
        });

        // Sync range inputs with number inputs
        ['currentAge', 'retirementAge', 'lifeExpectancy', 'monthlyIncome', 
         'monthlyExpenses', 'expenseRatio'].forEach(id => {
            const input = document.getElementById(id);
            const range = document.getElementById(id + 'Range');
            if (input && range) {
                input.addEventListener('input', () => range.value = input.value);
                range.addEventListener('input', () => input.value = range.value);
            }
        });
    }

    calculateRetirement() {
        const inputs = this.getInputs();
        const results = this.computeRetirement(inputs);
        this.displayResults(results);
        this.updateCharts(results);
    }

    getInputs() {
        return {
            currentAge: parseInt(document.getElementById('currentAge').value),
            retirementAge: parseInt(document.getElementById('retirementAge').value),
            lifeExpectancy: parseInt(document.getElementById('lifeExpectancy').value),
            monthlyIncome: parseFloat(document.getElementById('monthlyIncome').value),
            monthlyExpenses: parseFloat(document.getElementById('monthlyExpenses').value),
            expenseRatio: parseFloat(document.getElementById('expenseRatio').value) / 100,
            currentSavings: parseFloat(document.getElementById('currentSavings').value),
            monthlyInvestment: parseFloat(document.getElementById('monthlyInvestment').value),
            preReturnRate: parseFloat(document.getElementById('preReturnRate').value) / 100,
            postReturnRate: parseFloat(document.getElementById('postReturnRate').value) / 100,
            inflationRate: parseFloat(document.getElementById('inflationRate').value) / 100,
            epfContribution: parseFloat(document.getElementById('epfContribution').value) || 0,
            ppfInvestment: parseFloat(document.getElementById('ppfInvestment').value) || 0,
            npsInvestment: parseFloat(document.getElementById('npsInvestment').value) || 0
        };
    }

    computeRetirement(inputs) {
        // Calculate years until and during retirement
        const yearsToRetirement = inputs.retirementAge - inputs.currentAge;
        const yearsInRetirement = inputs.lifeExpectancy - inputs.retirementAge;

        // Calculate monthly expenses at retirement (adjusted for inflation)
        const monthlyExpensesAtRetirement = inputs.monthlyExpenses * 
            Math.pow(1 + inputs.inflationRate, yearsToRetirement) * 
            inputs.expenseRatio;

        // Calculate required corpus
        const monthlyReturnRate = inputs.postReturnRate / 12;
        const numberOfMonths = yearsInRetirement * 12;
        const requiredCorpus = monthlyExpensesAtRetirement * 
            ((1 - Math.pow(1 + monthlyReturnRate - inputs.inflationRate/12, -numberOfMonths)) / 
            (monthlyReturnRate - inputs.inflationRate/12));

        // Calculate expected corpus
        let expectedCorpus = inputs.currentSavings;
        const monthlyPreReturnRate = inputs.preReturnRate / 12;
        const totalMonthlyInvestment = inputs.monthlyInvestment + 
            inputs.epfContribution + 
            inputs.npsInvestment + 
            (inputs.ppfInvestment / 12);

        for (let month = 1; month <= yearsToRetirement * 12; month++) {
            expectedCorpus *= (1 + monthlyPreReturnRate);
            expectedCorpus += totalMonthlyInvestment;
        }

        // Calculate shortfall and additional investment needed
        const shortfall = Math.max(0, requiredCorpus - expectedCorpus);
        const additionalMonthlyInvestment = shortfall * 
            (monthlyPreReturnRate) / 
            (Math.pow(1 + monthlyPreReturnRate, yearsToRetirement * 12) - 1);

        return {
            requiredCorpus,
            expectedCorpus,
            shortfall,
            additionalMonthlyInvestment,
            monthlyExpensesAtRetirement,
            yearsToRetirement,
            yearsInRetirement
        };
    }

    displayResults(results) {
        this.result.style.display = 'block';
        
        this.result.querySelector('.required-corpus').textContent = 
            `₹${Math.round(results.requiredCorpus).toLocaleString('en-IN')}`;
        
        this.result.querySelector('.expected-corpus').textContent = 
            `₹${Math.round(results.expectedCorpus).toLocaleString('en-IN')}`;
        
        this.result.querySelector('.monthly-shortfall').textContent = 
            `₹${Math.round(results.monthlyExpensesAtRetirement).toLocaleString('en-IN')}`;
        
        this.result.querySelector('.additional-investment').textContent = 
            `₹${Math.round(results.additionalMonthlyInvestment).toLocaleString('en-IN')}`;
    }

    updateCharts(results) {
        // Update corpus growth chart
        this.updateCorpusChart(results);
        
        // Update investment distribution chart
        this.updateInvestmentChart();
    }

    updateCorpusChart(results) {
        const ctx = document.getElementById('corpusChart').getContext('2d');
        
        if (this.charts.corpus) {
            this.charts.corpus.destroy();
        }

        const years = Array.from(
            {length: results.yearsToRetirement}, 
            (_, i) => `Year ${i + 1}`
        );

        const corpusData = this.calculateCorpusGrowth(results);

        this.charts.corpus = new Chart(ctx, {
            type: 'line',
            data: {
                labels: years,
                datasets: [{
                    label: 'Expected Corpus',
                    data: corpusData,
                    borderColor: 'rgba(0, 102, 255, 1)',
                    backgroundColor: 'rgba(0, 102, 255, 0.1)',
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => '₹' + (value / 10000000).toFixed(2) + 'Cr'
                        }
                    }
                }
            }
        });
    }

    updateInvestmentChart() {
        const ctx = document.getElementById('investmentChart').getContext('2d');
        
        if (this.charts.investment) {
            this.charts.investment.destroy();
        }

        const inputs = this.getInputs();
        const monthlyTotal = inputs.monthlyInvestment + 
            inputs.epfContribution + 
            inputs.npsInvestment + 
            (inputs.ppfInvestment / 12);

        const data = [
            {
                label: 'Regular Investment',
                value: inputs.monthlyInvestment
            },
            {
                label: 'EPF',
                value: inputs.epfContribution
            },
            {
                label: 'NPS',
                value: inputs.npsInvestment
            },
            {
                label: 'PPF',
                value: inputs.ppfInvestment / 12
            }
        ].filter(item => item.value > 0);

        this.charts.investment = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.map(d => d.label),
                datasets: [{
                    data: data.map(d => d.value),
                    backgroundColor: [
                        'rgba(0, 102, 255, 0.8)',
                        'rgba(0, 102, 255, 0.6)',
                        'rgba(0, 102, 255, 0.4)',
                        'rgba(0, 102, 255, 0.2)'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                const percentage = (value / monthlyTotal * 100).toFixed(1);
                                return `${context.label}: ₹${value.toLocaleString('en-IN')} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    calculateCorpusGrowth(results) {
        const inputs = this.getInputs();
        const monthlyPreReturnRate = inputs.preReturnRate / 12;
        const totalMonthlyInvestment = inputs.monthlyInvestment + 
            inputs.epfContribution + 
            inputs.npsInvestment + 
            (inputs.ppfInvestment / 12);

        let corpus = inputs.currentSavings;
        const corpusData = [corpus];

        for (let year = 1; year <= results.yearsToRetirement; year++) {
            for (let month = 1; month <= 12; month++) {
                corpus *= (1 + monthlyPreReturnRate);
                corpus += totalMonthlyInvestment;
            }
            corpusData.push(corpus);
        }

        return corpusData;
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new RetirementCalculator();
}); 