class RDCalculator {
    constructor() {
        this.form = document.getElementById('rdForm');
        this.result = document.getElementById('rdResult');
        this.chart = null;

        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Form submission
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.calculateRD();
        });

        // Sync range inputs with number inputs
        ['rdMonthlyDeposit', 'rdInterestRate', 'rdTenure'].forEach(id => {
            const input = document.getElementById(id);
            const range = document.getElementById(id + 'Range');

            input.addEventListener('input', () => range.value = input.value);
            range.addEventListener('input', () => input.value = range.value);
        });
    }

    calculateRD() {
        const monthlyDeposit = parseFloat(document.getElementById('rdMonthlyDeposit').value);
        const interestRate = parseFloat(document.getElementById('rdInterestRate').value);
        const tenure = parseFloat(document.getElementById('rdTenure').value);
        const compounding = document.getElementById('rdCompounding').value;

        // Calculate compounding frequency
        const compoundingFrequency = compounding === 'monthly' ? 12 : 4;
        const ratePerPeriod = interestRate / (100 * compoundingFrequency);

        let maturityAmount = 0;
        const monthlyData = [];
        const totalDeposits = monthlyDeposit * tenure;

        // Calculate maturity amount using RD formula
        for (let month = 1; month <= tenure; month++) {
            const remainingMonths = tenure - month + 1;
            const quarterlyPeriods = Math.floor(remainingMonths / 3);
            
            let installmentValue = monthlyDeposit;
            for (let q = 0; q < quarterlyPeriods; q++) {
                installmentValue *= (1 + ratePerPeriod);
            }
            
            maturityAmount += installmentValue;
            
            monthlyData.push({
                month: month,
                deposits: monthlyDeposit * month,
                value: maturityAmount
            });
        }

        const interestEarned = maturityAmount - totalDeposits;

        this.displayResults(maturityAmount, totalDeposits, interestEarned);
        this.updateChart(monthlyData);
    }

    displayResults(maturityAmount, totalDeposits, interestEarned) {
        this.result.style.display = 'block';
        
        this.result.querySelector('.result-amount').textContent = 
            `₹${Math.round(maturityAmount).toLocaleString()}`;
        
        this.result.querySelector('.total-deposits').textContent = 
            `₹${Math.round(totalDeposits).toLocaleString()}`;
        
        this.result.querySelector('.interest-earned').textContent = 
            `₹${Math.round(interestEarned).toLocaleString()}`;
    }

    updateChart(monthlyData) {
        if (this.chart) {
            this.chart.destroy();
        }

        const ctx = document.getElementById('rdChart').getContext('2d');
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: monthlyData.map(d => `Month ${d.month}`),
                datasets: [
                    {
                        label: 'Total Deposits',
                        data: monthlyData.map(d => d.deposits),
                        borderColor: 'rgba(0, 102, 255, 0.5)',
                        backgroundColor: 'rgba(0, 102, 255, 0.1)',
                        fill: true
                    },
                    {
                        label: 'Account Value',
                        data: monthlyData.map(d => d.value),
                        borderColor: 'rgba(0, 102, 255, 1)',
                        backgroundColor: 'rgba(0, 102, 255, 0.2)',
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ₹${context.raw.toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => '₹' + value.toLocaleString()
                        }
                    }
                }
            }
        });
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new RDCalculator();
}); 