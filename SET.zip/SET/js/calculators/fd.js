class FDCalculator {
    constructor() {
        this.form = document.getElementById('fdForm');
        this.result = document.getElementById('fdResult');
        this.chart = null;

        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Form submission
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.calculateFD();
        });

        // Sync range inputs with number inputs
        ['fdPrincipal', 'fdInterestRate'].forEach(id => {
            const input = document.getElementById(id);
            const range = document.getElementById(id + 'Range');

            input.addEventListener('input', () => range.value = input.value);
            range.addEventListener('input', () => input.value = range.value);
        });
    }

    calculateFD() {
        const principal = parseFloat(document.getElementById('fdPrincipal').value);
        const interestRate = parseFloat(document.getElementById('fdInterestRate').value);
        const tenure = parseFloat(document.getElementById('fdTenure').value);
        const tenureType = document.getElementById('fdTenureType').value;
        const compounding = document.getElementById('fdCompounding').value;

        // Convert tenure to years
        let tenureInYears = tenure;
        if (tenureType === 'months') {
            tenureInYears = tenure / 12;
        } else if (tenureType === 'days') {
            tenureInYears = tenure / 365;
        }

        // Calculate compounding frequency
        let compoundingFrequency = 1;
        switch (compounding) {
            case 'monthly':
                compoundingFrequency = 12;
                break;
            case 'quarterly':
                compoundingFrequency = 4;
                break;
            case 'half-yearly':
                compoundingFrequency = 2;
                break;
        }

        // Calculate maturity amount using compound interest formula
        const rate = interestRate / (100 * compoundingFrequency);
        const time = tenureInYears * compoundingFrequency;
        const maturityAmount = principal * Math.pow(1 + rate, time);
        const interestEarned = maturityAmount - principal;

        this.displayResults(maturityAmount, principal, interestEarned);
        this.updateChart(tenureInYears, principal, maturityAmount);
    }

    displayResults(maturityAmount, principal, interestEarned) {
        this.result.style.display = 'block';
        
        this.result.querySelector('.result-amount').textContent = 
            `₹${Math.round(maturityAmount).toLocaleString()}`;
        
        this.result.querySelector('.principal-amount').textContent = 
            `₹${Math.round(principal).toLocaleString()}`;
        
        this.result.querySelector('.interest-earned').textContent = 
            `₹${Math.round(interestEarned).toLocaleString()}`;
    }

    updateChart(years, principal, maturityAmount) {
        const data = [
            { label: 'Principal', value: principal },
            { label: 'Interest', value: maturityAmount - principal }
        ];

        if (this.chart) {
            this.chart.destroy();
        }

        const ctx = document.getElementById('fdChart').getContext('2d');
        this.chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.map(d => d.label),
                datasets: [{
                    data: data.map(d => d.value),
                    backgroundColor: [
                        'rgba(0, 102, 255, 0.8)',
                        'rgba(0, 102, 255, 0.4)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                return `₹${Math.round(value).toLocaleString()}`;
                            }
                        }
                    }
                }
            }
        });
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new FDCalculator();
}); 