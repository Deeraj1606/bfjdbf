class PPFCalculator {
    constructor() {
        this.form = document.getElementById('ppfForm');
        this.result = document.getElementById('ppfResult');
        this.chart = null;

        this.initializeEventListeners();
    }

    initializeEventListeners() {
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.calculatePPF();
        });

        // Sync range inputs with number inputs
        ['ppfYearlyInvestment', 'ppfTenure'].forEach(id => {
            const input = document.getElementById(id);
            const range = document.getElementById(id + 'Range');

            input.addEventListener('input', () => range.value = input.value);
            range.addEventListener('input', () => input.value = range.value);
        });
    }

    calculatePPF() {
        const yearlyInvestment = parseFloat(document.getElementById('ppfYearlyInvestment').value);
        const interestRate = parseFloat(document.getElementById('ppfInterestRate').value) / 100;
        const tenure = parseInt(document.getElementById('ppfTenure').value);

        let balance = 0;
        const yearlyData = [];

        for (let year = 1; year <= tenure; year++) {
            balance = (balance + yearlyInvestment) * (1 + interestRate);
            yearlyData.push({
                year,
                balance,
                investment: yearlyInvestment * year,
                interest: balance - (yearlyInvestment * year)
            });
        }

        this.displayResults(yearlyData[tenure - 1]);
        this.updateChart(yearlyData);
    }

    displayResults(finalData) {
        this.result.style.display = 'block';
        
        this.result.querySelector('.result-amount').textContent = 
            `₹${Math.round(finalData.balance).toLocaleString('en-IN')}`;
        
        this.result.querySelector('.total-investment').textContent = 
            `₹${Math.round(finalData.investment).toLocaleString('en-IN')}`;
        
        this.result.querySelector('.interest-earned').textContent = 
            `₹${Math.round(finalData.interest).toLocaleString('en-IN')}`;
    }

    updateChart(yearlyData) {
        const ctx = document.getElementById('ppfChart').getContext('2d');
        
        if (this.chart) {
            this.chart.destroy();
        }

        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: yearlyData.map(d => `Year ${d.year}`),
                datasets: [
                    {
                        label: 'Total Balance',
                        data: yearlyData.map(d => d.balance),
                        borderColor: 'rgba(0, 102, 255, 1)',
                        backgroundColor: 'rgba(0, 102, 255, 0.1)',
                        fill: true
                    },
                    {
                        label: 'Total Investment',
                        data: yearlyData.map(d => d.investment),
                        borderColor: 'rgba(0, 102, 255, 0.5)',
                        backgroundColor: 'rgba(0, 102, 255, 0.05)',
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ₹${Math.round(context.raw).toLocaleString('en-IN')}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => '₹' + (value / 100000).toFixed(2) + 'L'
                        }
                    }
                }
            }
        });
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PPFCalculator();
}); 