class InvestmentCalculator {
    constructor() {
        this.initializeSIPCalculator();
        this.initializeLumpsumCalculator();
    }

    initializeSIPCalculator() {
        const form = document.getElementById('sipForm');
        const result = document.getElementById('sipResult');
        let chart = null;

        // Sync range inputs with number inputs
        ['Amount', 'Return', 'Years'].forEach(field => {
            const input = document.getElementById(`sip${field}`);
            const range = document.getElementById(`sip${field}Range`);
            
            input.addEventListener('input', () => range.value = input.value);
            range.addEventListener('input', () => input.value = range.value);
        });

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const amount = parseFloat(document.getElementById('sipAmount').value);
            const returnRate = parseFloat(document.getElementById('sipReturn').value);
            const years = parseInt(document.getElementById('sipYears').value);

            const { totalValue, totalInvestment, totalReturns, yearlyData } = this.calculateSIP(
                amount, returnRate, years
            );

            // Update result display
            result.style.display = 'block';
            result.querySelector('.result-amount').textContent = 
                `₹${Math.round(totalValue).toLocaleString('en-IN')}`;
            result.querySelector('.invested-amount').textContent = 
                `₹${Math.round(totalInvestment).toLocaleString('en-IN')}`;
            result.querySelector('.returns-amount').textContent = 
                `₹${Math.round(totalReturns).toLocaleString('en-IN')}`;

            // Update chart
            this.updateChart('sipChart', yearlyData, chart);
        });
    }

    calculateSIP(monthlyAmount, returnRate, years) {
        const monthlyRate = returnRate / 12 / 100;
        const months = years * 12;
        const yearlyData = [];

        let totalValue = 0;
        let totalInvestment = 0;

        for (let year = 0; year <= years; year++) {
            const monthsCompleted = year * 12;
            totalInvestment = monthlyAmount * monthsCompleted;
            
            totalValue = monthlyAmount * 
                ((Math.pow(1 + monthlyRate, monthsCompleted) - 1) / monthlyRate) * 
                (1 + monthlyRate);

            yearlyData.push({
                year,
                investment: totalInvestment,
                value: totalValue
            });
        }

        return {
            totalValue,
            totalInvestment,
            totalReturns: totalValue - totalInvestment,
            yearlyData
        };
    }

    updateChart(canvasId, data, chartInstance) {
        const ctx = document.getElementById(canvasId).getContext('2d');
        
        if (chartInstance) {
            chartInstance.destroy();
        }

        return new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.map(d => `Year ${d.year}`),
                datasets: [
                    {
                        label: 'Investment Value',
                        data: data.map(d => d.value),
                        borderColor: 'rgb(0, 102, 255)',
                        backgroundColor: 'rgba(0, 102, 255, 0.1)',
                        fill: true
                    },
                    {
                        label: 'Amount Invested',
                        data: data.map(d => d.investment),
                        borderColor: 'rgba(0, 102, 255, 0.5)',
                        backgroundColor: 'rgba(0, 102, 255, 0.05)',
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                return `${context.dataset.label}: ₹${Math.round(value).toLocaleString('en-IN')}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: value => '₹' + (value / 100000).toFixed(2) + 'L'
                        }
                    }
                }
            }
        });
    }

    // Similar implementation for Lumpsum calculator...
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new InvestmentCalculator();
}); 