class NPSCalculator {
    constructor() {
        this.form = document.getElementById('npsForm');
        this.result = document.getElementById('npsResult');
        this.charts = {
            corpus: null,
            allocation: null
        };

        this.initializeEventListeners();
        this.initializeTooltips();
    }

    initializeEventListeners() {
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.calculateNPS();
        });

        // Sync range inputs with number inputs
        ['npsMonthlyContribution', 'npsCurrentAge', 'npsEquityAllocation'].forEach(id => {
            const input = document.getElementById(id);
            const range = document.getElementById(id + 'Range');

            input.addEventListener('input', () => {
                range.value = input.value;
                if (id === 'npsEquityAllocation') {
                    this.updateAllocationChart(input.value);
                }
            });
            range.addEventListener('input', () => {
                input.value = range.value;
                if (id === 'npsEquityAllocation') {
                    this.updateAllocationChart(range.value);
                }
            });
        });
    }

    initializeTooltips() {
        // Add tooltips for complex fields
        const tooltips = {
            npsEquityAllocation: 'Maximum 75% equity allocation allowed until age 50',
            npsEquityReturn: 'Historical equity returns have averaged 12-15%',
            npsDebtReturn: 'Government securities typically return 7-9%'
        };

        Object.entries(tooltips).forEach(([id, text]) => {
            const element = document.getElementById(id);
            if (element) {
                element.parentElement.setAttribute('title', text);
            }
        });
    }

    calculateNPS() {
        const inputs = this.getInputs();
        const results = this.computeNPS(inputs);
        this.displayResults(results);
        this.updateCharts(results);
    }

    getInputs() {
        return {
            monthlyContribution: parseFloat(document.getElementById('npsMonthlyContribution').value),
            currentAge: parseInt(document.getElementById('npsCurrentAge').value),
            retirementAge: parseInt(document.getElementById('npsRetirementAge').value),
            equityAllocation: parseFloat(document.getElementById('npsEquityAllocation').value) / 100,
            equityReturn: parseFloat(document.getElementById('npsEquityReturn').value) / 100,
            debtReturn: parseFloat(document.getElementById('npsDebtReturn').value) / 100
        };
    }

    computeNPS(inputs) {
        const months = (inputs.retirementAge - inputs.currentAge) * 12;
        let equityCorpus = 0;
        let debtCorpus = 0;
        const yearlyData = [];

        for (let month = 1; month <= months; month++) {
            const contribution = inputs.monthlyContribution;
            const equityContribution = contribution * inputs.equityAllocation;
            const debtContribution = contribution * (1 - inputs.equityAllocation);

            equityCorpus = (equityCorpus + equityContribution) * (1 + inputs.equityReturn / 12);
            debtCorpus = (debtCorpus + debtContribution) * (1 + inputs.debtReturn / 12);

            if (month % 12 === 0) {
                const year = month / 12;
                yearlyData.push({
                    year,
                    equityCorpus,
                    debtCorpus,
                    totalCorpus: equityCorpus + debtCorpus,
                    totalInvestment: inputs.monthlyContribution * month
                });
            }
        }

        return {
            yearlyData,
            finalCorpus: equityCorpus + debtCorpus,
            equityCorpus,
            debtCorpus,
            totalInvestment: inputs.monthlyContribution * months,
            returns: (equityCorpus + debtCorpus) - (inputs.monthlyContribution * months)
        };
    }

    // ... rest of the class implementation with chart updates and result display ...
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new NPSCalculator();
}); 